/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package system.core;

import java.io.IOException;
import java.lang.reflect.Constructor;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Jean
 */
public class                            AppCore
{
    public static boolean               initPage(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        /*HttpSession                     session = request.getSession(true);
        SessionManager                  sessionManager = (SessionManager)objectFactory("SessionManager", session);*/
       /* Authorizer                      authorizer = initObject(session);
        MenuGenerator                   menuGenerator = initObject(session);*/
        
        /*if (sessionManager.checkSession(session) == false || authorizer.checkAuthorization() == false)
        {
            request.getRequestDispatcher("jsp/system/login.jsp").forward(request, response);
            return (false);
        }*/
        return (true);
    }
    
    private static Object               objectFactory(String className, HttpSession session) throws NoSuchMethodException, SecurityException
    {
        try
        {
            Class c = Class.forName(className);
            Constructor construct = c.getConstructor(c);
            
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
        return (new SessionManager());
    }
    
    private static SessionManager       initSessionManager(HttpSession session)
    {
        SessionManager                  sessionManager = (SessionManager)session.getAttribute("_sessionManager");
        
        if (sessionManager == null)
            sessionManager = new SessionManager();
        return (sessionManager);
    }
    
    private static Authorizer           initAuthorizer(HttpSession session)
    {
        Authorizer                      authorizer = (Authorizer)session.getAttribute("_authorizer");
        
        if (authorizer == null)
        {
            authorizer = new Authorizer();
            session.setAttribute("_authorizer", authorizer);
        }
        return (authorizer);
    }
    
    private static MenuGenerator        initMenuGenerator(HttpSession session)
    {
        MenuGenerator                   menuGenerator = (MenuGenerator)session.getAttribute("_menuGenerator");
        
        if (menuGenerator == null)
        {
            menuGenerator = new MenuGenerator();
            session.setAttribute("_menuGenerator", menuGenerator);
        }
        return (menuGenerator);
    }
}
