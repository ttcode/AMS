package system.core;

import java.io.IOException;
import java.io.Serializable;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Jean
 * 
 * SessionManager class abstract the creation and desctruction of sessions
 * 
 */
public class                    SessionManager implements Serializable
{
    /*
     * checkSession is used for verifying actual session state. User is
     * automatically redirected to login page if not logged to the system.
     */
    public boolean       checkSession(HttpSession session)
    {
        if (session == null || session.getAttribute("system_account") == null)
            return (false);
        return (true);
    }
    
    /*
     * destroySession is used during user logout, destroying the session.
     */
    public void          destroySession(HttpSession session)
    {   
        if (session != null)
        {
            if (session.getAttribute("system_account") != null)
                session.setAttribute("system_account", null);
            session.invalidate();
        }
    }
}
