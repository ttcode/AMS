/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package system.core;

import java.io.Serializable;

/**
 *
 * @author Jean
 */
public class                    Authorizer implements Serializable
{
    public boolean              checkAuthorization()
    {
        return (false);
    }
}
